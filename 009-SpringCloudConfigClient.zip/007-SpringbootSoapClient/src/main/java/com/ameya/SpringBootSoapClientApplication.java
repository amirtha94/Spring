package com.ameya;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.ameya.soap.student.Student;
import com.ameya.soap.student.StudentDetailsRequest;
import com.ameya.soap.student.StudentDetailsResponse;
import com.ameya.soap.wsclient.SOAPConnector;

@SpringBootApplication
public class SpringBootSoapClientApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(SpringBootSoapClientApplication.class, args);
	}
	@Bean
	public Student getStudent(SOAPConnector client) {
		StudentDetailsRequest request = new StudentDetailsRequest();
		request.setName("Kshiti");
		
		StudentDetailsResponse response =(StudentDetailsResponse) 
				client.callWebService("http://localhost:9001/service/student-details", request);
		//StudentDetailsResponse response =(StudentDetailsResponse) 
			//	client.callWebService("http://localhost:9011/service/student-details", request);
		System.out.println("Got Response As below ========= : "+response.toString()+"============"+response.getStudent().toString());
		Student student=response.getStudent();
		System.out.println("Name : "+response.getStudent().getName());
		System.out.println("Standard : "+response.getStudent().getStandard());
		System.out.println("Address : "+response.getStudent().getAddress());
		return student;
	}
}
