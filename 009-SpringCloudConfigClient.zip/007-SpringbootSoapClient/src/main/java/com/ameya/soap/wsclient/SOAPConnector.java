package com.ameya.soap.wsclient;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;

/*
 *  WebServiceGatewaySupport which basically injects one interface 
 *  with internal implementation of WebServiceTemplate which is 
 *  available by getWebServiceTemplate() method. 
 *  We will use this WebServiceTemplate to invoke the SOAP service. 
 */
public class SOAPConnector extends WebServiceGatewaySupport {

	
	public Object callWebService(String url, Object request){
		return getWebServiceTemplate().marshalSendAndReceive(url, request);
	}
}