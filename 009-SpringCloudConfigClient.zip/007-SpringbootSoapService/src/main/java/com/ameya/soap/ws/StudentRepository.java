package com.ameya.soap.ws;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import com.ameya.soap.student.Student;

@Component
public class StudentRepository {
	private static final Map<String, Student> students = new HashMap<>();

	@PostConstruct
	public void initData() {
		
		Student student = new Student();
		student.setName("Kshiti");
		student.setStandard(2);
		student.setAddress("Pune");
		students.put(student.getName(), student);
		
		student = new Student();
		student.setName("Saksham");
		student.setStandard(8);
		student.setAddress("Mumbai");
		students.put(student.getName(), student);
		
		student = new Student();
		student.setName("Sanjay");
		student.setStandard(6);
		student.setAddress("Chennai");
		students.put(student.getName(), student);
		
		student = new Student();
		student.setName("Amol");
		student.setStandard(7);
		student.setAddress("Delhi");
		students.put(student.getName(), student);
		
		
	}

	public Student findStudent(String name) {
		Assert.notNull(name, "The Student's name must not be null");
		return students.get(name);
	}
}